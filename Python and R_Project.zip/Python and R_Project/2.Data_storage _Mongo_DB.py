from flask import Flask, request, render_template, redirect, url_for
from pymongo import MongoClient
from datetime import datetime
import os

app = Flask(__name__)

# Initialize MongoDB client
mongo_client = MongoClient('mongodb://localhost:27017/')
db = mongo_client['healthcare_db']
patients_collection = db['patients']

# Home route with form
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        patient_data = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'date_of_birth': request.form['date_of_birth'],
            'age': int(request.form['age']),
            'gender': request.form['gender'],
            'email': request.form['email'],
            'phone': request.form.get('phone', ''),
            'total_income': float(request.form.get('total_income', 0)),
            'expenses': float(request.form.get('expenses', 0)),
            'medical_condition': request.form.get('medical_condition', ''),
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        patients_collection.insert_one(patient_data)
        return redirect(url_for('success'))

    return render_template('index.html')

# Success page
@app.route('/success')
def success():
    return render_template('success.html')

if __name__ == '__main__':
    app.run(debug=True)